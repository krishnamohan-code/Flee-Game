var frog=document.querySelector("img")
let moveBy=10
window.addEventListener("load",()=>{
    frog.style.position="absolute"
    frog.style.left=0;
    frog.style.top=0;
});
window.addEventListener("keyup",(e)=>{
     switch(e.key){
         case 'ArrowLeft':
             frog.style.left=parseInt(frog.style.left)-moveBy+"px";
             break;
             case 'ArrowRight':
                frog.style.left=parseInt(frog.style.left)+moveBy+"px";
                break;
                case 'ArrowUp':
             frog.style.top=parseInt(frog.style.top)-moveBy+"px";
             break;
             case 'ArrowDown':
             frog.style.top=parseInt(frog.style.top)+moveBy+"px";
             break;
     }
})